﻿# mesh_python_runtime_win_amd64_py312

## Target

* Windows 11 amd64 / x86_64 / x64
* CPython 3.12.4 embedded x64

`amd64` means standard 64-bit Intel/AMD processors. It does not mean ARM64.

## Purpose

This artifact provides a self-contained embedded Python runtime for Mesh P2P Messenger C++ integration.

The artifact is intended to run without:

* system Python;
* external `pip install`;
* external/global `site-packages`;
* virtual environment activation;
* manual environment configuration by the end user.

## Runtime root

The stable runtime root directory is:

```text
mesh_python_runtime/
```

Expected deployment layout:

```text
MeshApp.exe
mesh_python_runtime/
  python.exe
  pythonw.exe
  python3.dll
  python312.dll
  python312.zip
  python312._pth
  site-packages/
  smoke_test.py
  VERSION
  BUILD_INFO.txt
  MANIFEST.txt
  README_runtime.md
```

The C++ layer should receive the path to:

```text
./mesh_python_runtime
```

The C++ layer should not depend on system Python, global `site-packages`, `pip`, or virtual environments.

## Python path isolation

The artifact uses `python312._pth` to keep the embedded runtime isolated.

Expected `python312._pth` contents:

```text
python312.zip
.
site-packages

import site
```

This layout allows imports from the local artifact only.

## Included components

Included:

* CPython 3.12.4 embedded x64 runtime;
* `mesh_crypto`;
* `mesh_node_db`;
* `cryptography`;
* `keyring`;
* `python-dotenv`;
* runtime transitive dependencies.

## Excluded components

Excluded:

* `pytest`;
* `pytest-benchmark`;
* `mypy`;
* `black`;
* `ruff`;
* `tqdm`;
* `pynacl`;
* project tests;
* development virtual environments;
* repository metadata.

## Validation

Run from the parent directory that contains `mesh_python_runtime/`:

```powershell
cd .\mesh_python_runtime
.\python.exe .\smoke_test.py
```

Expected final line:

```text
SMOKE TEST OK
```

The smoke-test validates:

* local embedded Python startup;
* Python version and executable path;
* local `sys.path`;
* import of runtime dependencies;
* import of `mesh_crypto`;
* import of `mesh_node_db`;
* storage crypto encrypt/decrypt roundtrip;
* `NodeDatabase` schema initialization;
* basic repository write/read operations;
* encrypted-at-rest check for selected plaintext markers.

## Keyring note

`keyring` is included because it is used by master-key protection.

The Windows artifact validates runtime import availability. Full OS keyring behavior depends on the target user environment and should be tested separately by the C++ application integration layer.

## Release metadata

The artifact contains:

```text
VERSION
BUILD_INFO.txt
MANIFEST.txt
README_runtime.md
```

`VERSION` stores the release version.

`BUILD_INFO.txt` stores build metadata such as platform, architecture, Python runtime version, artifact name, and source commit.

`MANIFEST.txt` stores SHA256 hashes for files inside the runtime root.
