﻿from __future__ import annotations

import importlib
import platform
import sqlite3
import sys
import tempfile
from pathlib import Path


def _print_runtime_info() -> None:
    print(f"python = {sys.version}")
    print(f"platform = {platform.platform()}")
    print(f"executable = {sys.executable}")
    print(f"sqlite = {sqlite3.sqlite_version}")

    print("sys.path =")
    for item in sys.path:
        print(f"  {item}")


def _check_imports() -> None:
    required_modules = [
        "cryptography",
        "keyring",
        "dotenv",
        "mesh_crypto",
        "mesh_crypto.storage",
        "mesh_node_db",
    ]

    for module_name in required_modules:
        importlib.import_module(module_name)
        print(f"import {module_name} = ok")


def _check_storage_crypto_roundtrip() -> tuple[object, object]:
    from mesh_crypto import FileKeyStore, PasswordProtector
    from mesh_crypto.storage import decrypt_storage_field, encrypt_storage_field

    temp_dir = Path(tempfile.mkdtemp(prefix = "mesh_runtime_crypto_"))
    keystore_dir = temp_dir / "keystore"

    protector = PasswordProtector(
        password = "runtime-smoke-test-password",
        scrypt_n = 2 ** 14,
        scrypt_r = 8,
        scrypt_p = 1,
    )

    keystore = FileKeyStore(keystore_dir, protector)
    keystore.create_new(overwrite = True)

    key_id = keystore.generate_key("symmetric")

    plaintext = b"runtime-smoke-storage-plaintext"
    aad = b"runtime-smoke-storage-aad"

    envelope = encrypt_storage_field(
        keystore,
        plaintext,
        aad = aad,
        key_id = key_id,
    )
    decrypted = decrypt_storage_field(
        keystore,
        envelope,
        aad = aad,
    )

    if decrypted != plaintext:
        raise RuntimeError("storage crypto roundtrip failed")

    print("mesh_crypto storage roundtrip = ok")
    return keystore, key_id


def _check_node_db_roundtrip(keystore: object, key_id: object) -> None:
    from mesh_crypto.storage import decrypt_storage_field, encrypt_storage_field
    from mesh_node_db import (
        CallableStorageCryptoProvider,
        ChatParticipantRecord,
        ChatRecord,
        MessageRecord,
        NodeDatabase,
        NodeDBCryptoAdapter,
        PeerRecord,
    )

    temp_dir = Path(tempfile.mkdtemp(prefix = "mesh_runtime_db_"))
    db_path = temp_dir / "runtime_smoke.db"

    provider = CallableStorageCryptoProvider(
        keystore = keystore,
        encrypt_storage_field = encrypt_storage_field,
        decrypt_storage_field = decrypt_storage_field,
    )
    crypto_adapter = NodeDBCryptoAdapter(
        provider = provider,
        active_storage_key_id = key_id,
    )

    marker_peer_name = "Runtime Smoke Peer"
    marker_chat_name = "Runtime Smoke Chat"
    marker_message = b"RUNTIME_SMOKE_SECRET_MESSAGE_7f2c4e"

    db = NodeDatabase(str(db_path), crypto_adapter = crypto_adapter)

    try:
        db.open()
        db.initialize()

        db.peers.add(
            PeerRecord(
                peer_id = "peer-runtime-smoke",
                display_name = marker_peer_name,
                public_key = b"runtime-smoke-public-key",
                created_at = 1000,
                updated_at = 1000,
                is_deleted = False,
                deleted_at = None,
            )
        )

        db.chats.add(
            ChatRecord(
                chat_id = "chat-runtime-smoke",
                chat_type = "direct",
                chat_name = marker_chat_name,
                created_at = 1001,
                updated_at = 1001,
            )
        )

        db.chat_participants.add(
            ChatParticipantRecord(
                chat_id = "chat-runtime-smoke",
                peer_id = "peer-runtime-smoke",
                joined_at = 1002,
            )
        )

        db.messages.add(
            MessageRecord(
                message_id = "msg-runtime-smoke",
                chat_id = "chat-runtime-smoke",
                sender_id = "peer-runtime-smoke",
                created_at = 1003,
                updated_at = 1003,
                payload = marker_message,
                attachment_hash = None,
            )
        )

        peer = db.peers.read("peer-runtime-smoke")
        chat = db.chats.read("chat-runtime-smoke")
        message = db.messages.read("msg-runtime-smoke")
        listed_messages = db.messages.list_by_chat("chat-runtime-smoke", limit = 10)

        if peer is None or peer.display_name != marker_peer_name:
            raise RuntimeError("peer repository roundtrip failed")

        if chat is None or chat.chat_name != marker_chat_name:
            raise RuntimeError("chat repository roundtrip failed")

        if message is None or message.payload != marker_message:
            raise RuntimeError("message repository roundtrip failed")

        if len(listed_messages) != 1 or listed_messages[0].payload != marker_message:
            raise RuntimeError("message list_by_chat roundtrip failed")

    finally:
        db.close()

    forbidden_markers = [
        marker_peer_name.encode("utf-8"),
        marker_chat_name.encode("utf-8"),
        marker_message,
    ]

    storage_files = [
        path
        for path in temp_dir.glob("runtime_smoke.db*")
        if path.is_file()
    ]

    if not storage_files:
        raise RuntimeError("database files were not created")

    for storage_file in storage_files:
        data = storage_file.read_bytes()
        for marker in forbidden_markers:
            if marker in data:
                raise RuntimeError(
                    f"plaintext marker leaked into database file: {storage_file.name}"
                )

    print("mesh_node_db encrypted-at-rest roundtrip = ok")


def main() -> None:
    _print_runtime_info()
    _check_imports()

    keystore, key_id = _check_storage_crypto_roundtrip()
    _check_node_db_roundtrip(keystore, key_id)

    print("SMOKE TEST OK")


if __name__ == "__main__":
    main()